Sidharrth Nagappan- 1181102313
Tan Zhi Hang- 1191302698
Kan Eugene- 1191302380

The Streamlit application is hosted at: https://covid-ml-love-story.herokuapp.com/

If you wish to run the Streamlit application from scratch:

cd "Streamlit Application"
pip install requirements.txt
streamlit run main.py

The trained LSTM model is saved as "lstm-time-series.h5".
